package com.example.joserafael.spinner_new;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    SeekBar sk;
    TextView texto;

    //Creamos un progress inicial
    int progress= 24;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Relacionamos nuestra elementos
        sk = (SeekBar) findViewById(R.id.sk);
        texto = (TextView) findViewById(R.id.texto);

        //Asignamos un máximo a nuestro progress y el progress actual o inicial
        sk.setMax(100);
        sk.setProgress(progress);


        //Cambiamos nuestro texto por el progress actual
        texto.setText("" + progress);

        //Modificamos el tamaño de texto por el progress actual
        texto.setTextSize(progress);

        //Hacemos uso del listener OnseekBarChangeListener() y el método
        //onProgressChanged
        sk.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                progress = i;
                texto.setText("" + progress);
                texto.setTextSize(progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }

        });
    }
}
