package com.example.joserafael.listview_nuevo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView texto;
    private ListView lista;

    private String nombres [] = {"Juan", "José", "María", "Samuel", "Sandra"};
    private String edades [] = {"18", "10", "25", "30", "55"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        texto = (TextView)findViewById(R.id.texto);
        lista = (ListView)findViewById(R.id.lista);

        //Agregamos al ListView los nombres que mostrará (guardados en el vector "nombres")
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, nombres);
        //ArrayAdapter <String> adapter = new ArrayAdapter<String>(this, R.layout.list_item_listview, nombres);
        lista.setAdapter(adapter);

        //Creamos clase anónima
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //Modificamos el TextView

                //La "i" es el entero pasado por parámetro a la clase anónima
                texto.setText("La edad de "+ lista.getItemAtPosition(i) + " es "+ edades[i] + " años");
            }
        });
    }
}
