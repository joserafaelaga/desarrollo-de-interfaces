package com.example.joserafael.spinner_new;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText et1;
    private EditText et2;
    private TextView tv;
    private Spinner sp1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Creamos objetos para crear comunicación con nuestros componentes
        et1 = (EditText)findViewById(R.id.txt_num1);
        et2 = (EditText)findViewById(R.id.txt_num2);
        tv = (TextView)findViewById(R.id.resultado);
        sp1 = (Spinner) findViewById(R.id.spinner);

        String [] opciones = {"Sumar", "Restar"};

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, opciones);
        //ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.spinner_item_valores, opciones);



        sp1.setAdapter(adapter);
    }

    //Método para el método calcular
    //View como parámetro para crear relación cuando se pulsa el botón
    public void calcular(View view){
        //Recogemos lo que devuelve y lo convertimos a String
        String valor1 = et1.getText().toString();
        String valor2 = et2.getText().toString();

        //Parseamos a entero
        int num1 = Integer.parseInt(valor1);
        int num2 = Integer.parseInt(valor2);

        String seleccion = sp1.getSelectedItem().toString();

        int operacion = 0;
        if(seleccion.equals("Sumar")){
            operacion = num1 + num2;
        }else if(seleccion.equals("Restar")){
            operacion = num1 - num2;
        }

        String result = String.valueOf(operacion);

        //result = String.valueOf(operacion);
        //Cambiamos el texto de "Resultado"
        tv.setText(result);
    }
}
