package com.example.joserafael.parametros;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText texto1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        texto1 = (EditText) findViewById(R.id.texto1);
    }

    //Método para el botón "siguiente"

    public void siguiente (View view){
        //Importante poner el nombre de la parte lógica de la aplicación con el .class
        //Primer parámetro origen, segundo destino
        Intent i = new Intent (this, Main2Activity.class);

        //Enviamos datos
        //Primer parámetro variable, segundo lo que queremos enviar
        i.putExtra("dato", texto1.getText().toString());

        //Lanzamos nueva Activity
        startActivity(i);


    }
}
