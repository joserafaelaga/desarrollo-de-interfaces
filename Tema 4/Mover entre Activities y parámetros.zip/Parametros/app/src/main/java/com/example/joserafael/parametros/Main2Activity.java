package com.example.joserafael.parametros;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    private TextView texto2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        //Creamos relación para comunicarse la parte lógica con la gráfica
        texto2 = (TextView) findViewById(R.id.texto2);

        //Recogemos datos enviado desde la otra Activity
        String parametro_recibido = getIntent().getStringExtra("dato");

        //Sustituimos el texto

        texto2.setText("Hola "+parametro_recibido);
    }

    //Método para el botón regresar

    public void regresar (View view){
        //Importante poner el nombre de la parte lógica de la aplicación con el .class
        //Primer parámetro origen, segundo destino
        Intent e = new Intent (this, MainActivity.class);

        //Lanzamos nueva Activity
        startActivity(e);

    }
}
